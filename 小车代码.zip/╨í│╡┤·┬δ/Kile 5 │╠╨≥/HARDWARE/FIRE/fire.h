#ifndef __FIRE_H
#define __FIRE_H

#include "sys.h"

#define FD1 PCin(9)

void Fire_GPIO_Init(void);
	


#endif


