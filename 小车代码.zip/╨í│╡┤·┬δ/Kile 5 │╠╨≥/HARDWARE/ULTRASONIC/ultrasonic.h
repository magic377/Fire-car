#ifndef _ultrasonic_H
#define _ultrasonic_H
#include "sys.h"

//------------------------------------------------------------��ֲ�޸���-----------------------------------------------------------------------

#define ULTRA_PORT	  GPIOC
#define ULTRA_CLK     RCC_AHB1Periph_GPIOC
#define ULTRA_TRIG	  GPIO_Pin_6
#define ULTRA_ECHO	  GPIO_Pin_8

#define TRIG_Send  PCout(6)
#define ECHO_Reci  PCin(8)


//---------------------------------------------------------------------------------------------------------------------------------------------
void Ultran_Init(void);
void Ultra_Ranging(float *p);

#endif

