#ifndef __MOTOR_H_
#define __MOTOR_H_

#include "sys.h"

//ȡ�ٶȲ�
#define ina1 (5+speed_left)				   
#define ina2 (5-speed_left)
#define inb1 (5+speed_right)
#define inb2 (5-speed_right)


#define motor0 (46+motor0_angel)		   //��ʱ�ж���11us��Ӧ�����1�ȣ�46��Ӧ0.5MS��ÿ��1��ʾת1��



#define MotorON {PDout(9) = 1; PDout(10) = 0;}
#define MotorOFF {PDout(9) = 0; PDout(10) = 0;}





/*����궨��*/
#define left1on GPIO_SetBits(GPIOB,GPIO_Pin_7)
#define left1off GPIO_ResetBits(GPIOB,GPIO_Pin_7)

#define left2on GPIO_SetBits(GPIOA,GPIO_Pin_4)
#define left2off GPIO_ResetBits(GPIOA,GPIO_Pin_4)

#define right1on GPIO_SetBits(GPIOC,GPIO_Pin_8)
#define right1off GPIO_ResetBits(GPIOC,GPIO_Pin_8)

#define right2on GPIO_SetBits(GPIOC,GPIO_Pin_7)
#define right2off GPIO_ResetBits(GPIOC,GPIO_Pin_7)




/*����궨��*/
#define motor0on GPIO_SetBits(GPIOA,GPIO_Pin_8)        //���
#define motor0off GPIO_ResetBits(GPIOA,GPIO_Pin_8)

//ˮ�ó�ʼ��
void Motor_Water_GPIO_Init(void);
void Motor_GPIO_Init(void);
void ControlSpeed(int speed);

void dianji(u8 i);

#endif
